var cars = [
  "Huracan",
  "Aventador",
  "Countach"
];

var images = [
  "images/Lamborghini-Huracan.png",
  "images/Lamborghini-Aventador.png",
  "images/Lamborghini-Countach.png"
];

var prices = [
  "$208,000",
  "$500,000",
  "$300,000"
];

var speeds = [
  "202 mph",
  "217 mph",
  "185 mph"
];

var accelTimes = [
  "2.9 sec.",
  "2.9 sec.",
  "5.3 sec."
];

var qtrMile = [
  "10.9. sec.",
  "10.3 sec.",
  "13.5 sec."
];

var horsepower = [
  "621 bhp",
  "749 bhp",
  "434 bhp"
];

var weights = [
  "1.57 tons (3,135 lbs.)",
  "1.81 tons (3,615 lbs.)",
  "1.32 tons (2,646 lbs.)"
];

var facts = [
  "The Italian police force use special models of the Lamborghini Huracan as patrol cars. There is a compartment in the front that can be used to hold organs needing to be transported quickly.",
  "Similar to te Huracan, the Aventador has many different versions, ranging from the SVJ, a performance focused style, to the roofless Aventador J with a suprising amount of power packed into it.",
  "The name comes from a swear word, exclaimed by the head of the Bertone design house when seeing the car's design for the first time."
];

var modelYear = [
  "2014",
  "2011",
  "1974"
];