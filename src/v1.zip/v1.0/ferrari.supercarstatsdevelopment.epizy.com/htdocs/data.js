var cars = [

  "Roma",

  "LaFerrari",

  "FXX K"

];



var images = [

  "images/Ferrari-Roma.png",

  "images/LaFerrari.png",

  "images/Ferrari-FXX-K.png"

];



var prices = [

  "$340,000",

  "$1.5 million",

  "$2.6 million"

];



var speeds = [

  "199 mph",

  "220 mph",

  "249 mph"

];



var accelTimes = [

  "3.2 sec.",

  "2.4 sec.",

  "2.6. sec."

];



var qtrMile = [

  "11.2 sec.",

  "9.7 sec.",

  "9.7 sec."

];



var horsepower = [

  "604 bhp",

  "936 bhp",

  "836 bhp"

];



var weights = [

  "1.73 tons (3,461 lbs.)",

  "1.75 tons (3,494 lbs.)",

  "1.28 tons (2,568 lbs.)"

];



var facts = [

  "The key to this car is a key fob that communicates to the car to allow the dirver to start the car. The design of the small, square key is the Ferrari logo.",

  "This car was one of the first super/sports cars to be built with an electric/gas hybrid motor. It is also rear wheel drive, while many other high-end racing cars are four-wheel drive.",

  "This car is the result of extensive research and development on the LaFerrari model. It has been redesigned to improve its performance on tracks by removing as much weight as possible."

];



var modelYear = [

  "2021",

  "2014",

  "2017"

];